<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class Userdata extends Seeder
{
    public function run()
    {
        $data = [
            [
                'username' => 'fauzi',
                'role' => 'manajemen produk',
                'password' => password_hash('fauzi123', PASSWORD_DEFAULT),
                'is_aktif' => 'true'
            ],
            [
                'username' => 'user1',
                'role' => 'user',
                'password' => password_hash('user123', PASSWORD_DEFAULT),
                'is_aktif' => 'false'
            ],
            [
                'username' => 'user2',
                'role' => 'user',
                'password' => password_hash('user123', PASSWORD_DEFAULT),
                'is_aktif' => 'false'
            ],
            [
                'username' => 'user3',
                'role' => 'user',
                'password' => password_hash('user123', PASSWORD_DEFAULT),
                'is_aktif' => 'false'
            ],
            [
                'username' => 'user4',
                'role' => 'user',
                'password' => password_hash('user123', PASSWORD_DEFAULT),
                'is_aktif' => 'false'
            ],
            
        ];

        $this->db->table('user')->insertBatch($data);
    }
}
