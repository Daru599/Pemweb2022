<h1>Mohon maaf Pak, seperti yang Bapak ketahui codingan saya hilang pada saat di lab. Berikut adalah codingan tugas kemarin, namun dokumentasi output program yang saya cantumkan merupakan hasil dari ngoding di lab</h1>
<h2>Output program lupa kurang register dan login</h2>
